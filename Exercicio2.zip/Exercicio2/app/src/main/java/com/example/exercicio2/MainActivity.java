package com.example.exercicio2;

import android.os.Bundle;
import android.security.keystore.StrongBoxUnavailableException;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private boolean isInternalChange = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //--------------------------------------------- Campo Nome ------------------------------------------------------------
        EditText editTextNome = findViewById(R.id.edit_nome);

        editTextNome.setFilters(new InputFilter[]{
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                        StringBuilder nomeDigitado = new StringBuilder();

                        for (int i = start; i < end; i++){
                            char currentChar = source.charAt(i);
                            if(Character.isLetter(currentChar) || currentChar == ' '){
                                nomeDigitado.append(currentChar);
                            }
                            if(nomeDigitado.length() == 0) {
                                return "";
                            }
                        }
                        return nomeDigitado.toString();
                    }
                }
        });

        editTextNome.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!isInternalChange) {
                    isInternalChange = true;
                    String textoMaiusculo = s.toString().toUpperCase();
                    editTextNome.setText(textoMaiusculo);
                    editTextNome.setSelection(textoMaiusculo.length());
                    isInternalChange = false;
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //------------------------------------------------------- Campo Email ------------------------------------------------------
        EditText editTextEmail = findViewById(R.id.edit_email);
        editTextEmail.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);

        //------------------------------------------------------ Campo Telefone ----------------------------------------------------
        EditText editTextTelefone = findViewById(R.id.edit_telefone);

        editTextTelefone.setInputType(InputType.TYPE_CLASS_PHONE);
        /*editTextTelefone.setFilters(new InputFilter[]{
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                        StringBuilder filteredStringTelefone = new StringBuilder();
                        for (int i = start; i < end; i++){
                            if(Character.isDigit(source.charAt(i))){
                                filteredStringTelefone.append(source.charAt(i));
                            }
                        }
                        if(filteredStringTelefone.length() == 0){
                            return "";
                        }
                        return filteredStringTelefone.toString();
                    }
                }
        });*/

        RadioGroup radSexSelected = findViewById(R.id.radio_sexo);
        CheckBox checkBoxMusica = findViewById(R.id.checkbox_musica);
        CheckBox checkBoxCinema = findViewById(R.id.checkbox_cinema);
        CheckBox checkBoxEsporte = findViewById(R.id.checkbox_esporte);
        CheckBox checkBoxGastronomia = findViewById(R.id.checkbox_gastronomia);
        Switch switchNotificacoes = findViewById(R.id.switch_notificacoes);
        Button botaoExibir = findViewById(R.id.button_exibir);
        TextView textViewDados = findViewById(R.id.text_view_dados);

        //------------------------------------------------------- Funcionalidade Botão Exibir ---------------------------------------------
        botaoExibir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = editTextNome.getText().toString();
                String sexo = "";
                int selectedSexoId = radSexSelected.getCheckedRadioButtonId();
                if(selectedSexoId != -1){
                    RadioButton selectedSexo = findViewById(selectedSexoId);
                    sexo = selectedSexo.getText().toString();
                }
                String email = editTextEmail.getText().toString();
                String telefone = editTextTelefone.getText().toString();
                //------------ Montando String Preferências ------------------------------
                StringBuilder preferenciasSelcionadas = new StringBuilder();
                CheckBox[] checkBoxes = {checkBoxMusica, checkBoxCinema, checkBoxEsporte, checkBoxGastronomia};
                String[] preferenciaLabes = {"Música", "Cinema", "Esporte", "Gastronomia"};
                for(int i = 0; i < checkBoxes.length; i++){
                    if(checkBoxes[i].isChecked()){
                        preferenciasSelcionadas.append(preferenciaLabes[i]).append(", ");
                    }
                }
                if(preferenciasSelcionadas.length() > 0){
                    preferenciasSelcionadas.delete(preferenciasSelcionadas.length() - 2, preferenciasSelcionadas.length());
                }

                String notificacoes = switchNotificacoes.isChecked() ? "On" : "Off";

                String dados = "Nome: " + nome + "\n" + "Sexo: " + sexo + "\n" + "Email: " + email + "\n" + "Telefone: " + telefone + "\n" + "Preferências: " + preferenciasSelcionadas + "\n" + "Ativar notificações: " +  notificacoes;

                textViewDados.setText(dados);
            }
        });

        // ------------------------------------------- Botão Limpar -----------------------------------------------------------------

        Button botaoLimpar = findViewById(R.id.button_limpar);
        
        botaoLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textViewDados.setText("");
            }
        });
    }
}