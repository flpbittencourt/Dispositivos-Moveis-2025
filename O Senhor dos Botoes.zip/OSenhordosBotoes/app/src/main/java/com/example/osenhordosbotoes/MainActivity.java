package com.example.osenhordosbotoes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //2ª forma
        Button btnFilme2 = findViewById(R.id.btnFilme2);
        btnFilme2.setOnClickListener(this);

        //3ª forma
        Button btnFilme3 = findViewById(R.id.btnFilme3);
        btnFilme3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Filme3Activity.class);
                startActivity(intent);
            }
        });
    }

    //1ª forma (desuso)
    public void abrir(View view) {
        Intent intent = new Intent(this, Filme1Acivity.class);
        startActivity(intent);
    }

    //2º forma
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnFilme2){
            startActivity(new Intent(this, Filme2Activity.class));
        }

    }
}